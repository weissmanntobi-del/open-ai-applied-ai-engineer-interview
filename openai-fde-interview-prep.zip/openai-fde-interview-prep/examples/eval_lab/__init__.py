"""Offline evaluation example."""
