"""Practice examples."""
